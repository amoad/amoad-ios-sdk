//
//  AMoAdCocos2dxModule.mm
//
//  Created by AMoAd on 2015/07/15.
//
#import "AMoAdCocos2dxModule.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import "AMoAdView.h"

#pragma mark - Utilities

static NSString* string_with_cstring(const char *c) {
  return [NSString stringWithCString:c encoding:NSUTF8StringEncoding];
}

static UIViewController* get_view_controller() {
  UIWindow *mainWindow = [[UIApplication sharedApplication].windows objectAtIndex:0];
  return mainWindow.rootViewController;
}

static AMoAdView *find_amoad_view(NSString *sid) {
  for (id view in get_view_controller().view.subviews) {
    if ([view isKindOfClass:[AMoAdView class]]) {
      AMoAdView *amoadView = (AMoAdView *)view;
      if ([amoadView.sid isEqualToString:sid]) {
        return amoadView;
      }
    }
  }
  return nil;
}


#pragma mark - Implements

void AMoAdCocos2dxModule::registerInlineAd(const char *cSid, AMoAdCocos2dxModule::AdSize adSize,
  AMoAdCocos2dxModule::HorizontalAlign hAlign, AMoAdCocos2dxModule::VerticalAlign vAlign,
  AMoAdCocos2dxModule::AdjustMode adjustMode, int x/* = 0*/, int y/* = 0*/)
{
  NSString *sid = string_with_cstring(cSid);
  AMoAdView *amoadView = [[AMoAdView alloc] initWithSid:sid bannerSize:AMoAdBannerSize(adSize) hAlign:AMoAdHorizontalAlign(hAlign) vAlign:AMoAdVerticalAlign(vAlign) adjustMode:AMoAdAdjustMode(adjustMode) x:CGFloat(x) y:CGFloat(y)];
  if (amoadView) {
    UIViewController *viewController = get_view_controller();
    amoadView.hidden = YES;
    [viewController.view addSubview:amoadView];
  }
}

void AMoAdCocos2dxModule::registerInterstitialAd(const char *cSid)
{
  // TODO Interstitial
}

void AMoAdCocos2dxModule::setDefaultImageName(const char *cSid, const char *cImageName)
{
  NSString *sid = string_with_cstring(cSid);
  AMoAdView *amoadView = find_amoad_view(sid);
  if (cImageName) {
    NSString *imageName = string_with_cstring(cImageName);
    amoadView.image = [UIImage imageNamed:imageName];
  }
}

void AMoAdCocos2dxModule::setRotateTransition(const char *cSid, AMoAdCocos2dxModule::RotateTransition rotateTrans)
{
  NSString *sid = string_with_cstring(cSid);
  AMoAdView *amoadView = find_amoad_view(sid);
  if (amoadView) {
    amoadView.rotateTransition = AMoAdRotateTransition(rotateTrans);
  }
}

void AMoAdCocos2dxModule::setClickTransition(const char *cSid, AMoAdCocos2dxModule::ClickTransition clickTrans)
{
  NSString *sid = string_with_cstring(cSid);
  AMoAdView *amoadView = find_amoad_view(sid);
  if (amoadView) {
    amoadView.clickTransition = AMoAdClickTransition(clickTrans);
  }
}

void AMoAdCocos2dxModule::show(const char *cSid)
{
  NSString *sid = string_with_cstring(cSid);
  AMoAdView *amoadView = find_amoad_view(sid);
  if (amoadView) {
    [amoadView show];
  }
}

void AMoAdCocos2dxModule::hide(const char *cSid)
{
  NSString *sid = string_with_cstring(cSid);
  AMoAdView *amoadView = find_amoad_view(sid);
  if (amoadView) {
    [amoadView hide];
  }
}

void AMoAdCocos2dxModule::dispose(const char *cSid)
{
  NSString *sid = string_with_cstring(cSid);
  AMoAdView *amoadView = find_amoad_view(sid);
  if (amoadView) {
    [amoadView removeFromSuperview];
  }
}
